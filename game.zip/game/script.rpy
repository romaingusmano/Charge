﻿# Vous pouvez placer le script de votre jeu dans ce fichier.

# Déclarez sous cette ligne les images, avec l'instruction 'image'
# ex: image eileen heureuse = "eileen_heureuse.png"

define config.single_movie_channel = "video"
default volume_ouvert = False

# Déclaration des videos

image a1 = Movie(play="A1_FINAL.webm", channel="movie", loop=False, keep_last_frame=True)
image b1 = Movie(play="B1_final.webm", channel="movie", loop=False, keep_last_frame=True)
image b2 = Movie(play="B2_final.webm", channel="movie", loop=False)
image c1 = Movie(play="C1_final.webm", channel="movie", loop=False)
image d1 = Movie(play="D1_final.webm", channel="movie", loop=False, keep_last_frame=True)
image e1 = Movie(play="E1_final.webm", channel="movie", loop=False)
image e2 = Movie(play="E2_final.webm", channel="movie", loop=False)
image f1 = Movie(play="F1_FINAL.webm", channel="movie", loop=False)
image g1 = Movie(play="G1_FINAL.webm", channel="movie", loop=False, keep_last_frame=True)
image h1 = Movie(play="H1_final.webm", channel="movie", loop=False, keep_last_frame=True)
image i1 = Movie(play="I1_final.webm", channel="movie", loop=False)
image i2 = Movie(play="I2_final.webm", channel="movie", loop=False)
image j1 = Movie(play="J1_final.webm", channel="movie", loop=False)


# Le jeu commence ici

label start:
    $ _skipping = False
    $ renpy.config.allow_skipping = False
    scene black
    window hide
    show a1
    show screen lecteur_video
    $ renpy.pause(67, hard=True)  # 30 - 15 = 15 secondes avant la fin
    hide screen lecteur_video
    menu:
        "Escalader la grue":
            jump B1
        "Faire demi-tour":
            jump C1
        "Utiliser le vaisseau":
            jump D1
        "Reconstruire le pont":
            jump E1


label B1:
    $ _skipping = False
    $ renpy.config.allow_skipping = False
    scene black
    show b1
    show screen lecteur_video
    $ renpy.pause(31, hard=True)
    hide screen lecteur_video
    menu:
        "Redescendre sur la plateforme":
            jump H1
        "Continuer sur le câble":
            jump I1


label D1:
    $ _skipping = False
    $ renpy.config.allow_skipping = False
    scene black
    show d1
    show screen lecteur_video
    $ renpy.pause(12, hard=True)
    hide screen lecteur_video
    menu:
        "Appuyer sur le bouton vert":
            jump G1
        "Appuyer sur le bouton rouge":
            jump F1


label H1:
    $ _skipping = False
    $ renpy.config.allow_skipping = False
    scene black
    show h1
    show screen lecteur_video
    $ renpy.pause(5, hard=True)
    hide screen lecteur_video
    menu:
        "Reconstruire le pont":
            jump E2
        "Utiliser le vaisseau":
            jump F1


label G1:
    $ _skipping = False
    $ renpy.config.allow_skipping = False
    scene black
    show g1
    show screen lecteur_video
    $ renpy.pause(23, hard=True)
    hide screen lecteur_video
    menu:
        "Escalader la grue":
            jump B2
        "Reconstruire le pont":
            jump E2


label B2:
    
    scene black
    show b2
    show screen lecteur_video
    $ renpy.pause(31.0, hard=True)


label I2:  
    
    scene black
    show i2
    show screen lecteur_video
    $ renpy.pause(38.0, hard=True)
    jump end


label C1:
    
    scene black
    show c1
    show screen lecteur_video
    $ renpy.pause(22.0, hard=True)
    jump end_choice


label E2:
    
    scene black
    show e2
    show screen lecteur_video
    $ renpy.pause(57.0, hard=True)
    jump end

label I1:
    
    scene black
    show i1
    show screen lecteur_video
    $ renpy.pause(38.0, hard=True)
    jump end


label F1:
    
    scene black
    show f1
    show screen lecteur_video
    $ renpy.pause(55.0, hard=True)
    jump end


label E1:
    
    scene black
    show e1
    show screen lecteur_video
    $ renpy.pause(57.0, hard=True)
    jump end


label end:
    scene black
    show j1
    $ renpy.pause(15.0, hard=True)
    hide screen lecteur_video
    
label end_choice:
    menu:
        centered "Merci d'avoir joué ! Souhaites-tu répondre à notre formulaire (4 questions pour donner ton avis)?"
        "Oui, répondre au formulaire":
            $ import webbrowser
            $ webbrowser.open("https://www.noxstories.com/post-aventure_charge")

        "Non, quitter le jeu":
            pass
    return
